package Model.Parkir;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class ModelTable extends AbstractTableModel {
    private List<ModelParkir> data;
    private String[] columns = {"ID", "Nama Pemilik", "Plat Nomor", "Merk Kendaraan", "Durasi Parkir", "Total Biaya"}; // Tambahkan kolom baru untuk total biaya

    public ModelTable(List<ModelParkir> data) {
        this.data = data;
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        ModelParkir parkir = data.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return parkir.getId();
            case 1:
                return parkir.getNamaPemilik();
            case 2:
                return parkir.getPlatNomor();
            case 3:
                return parkir.getMerkKendaraan();
            case 4:
                return parkir.getDurasiParkir();
            case 5:
                return parkir.getTotalBiaya(); // Tambahkan total biaya parkir ke dalam tabel
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columns[column];
    }
}
