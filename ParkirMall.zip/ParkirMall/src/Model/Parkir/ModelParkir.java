package Model.Parkir;

public class ModelParkir {
    private int id;
    private String namaPemilik;
    private String platNomor;
    private String merkKendaraan;
    private int durasiParkir;
    private int totalBiaya;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNamaPemilik() {
        return namaPemilik;
    }

    public void setNamaPemilik(String namaPemilik) {
        this.namaPemilik = namaPemilik;
    }

    public String getPlatNomor() {
        return platNomor;
    }

    public void setPlatNomor(String platNomor) {
        this.platNomor = platNomor;
    }

    public String getMerkKendaraan() {
        return merkKendaraan;
    }

    public void setMerkKendaraan(String merkKendaraan) {
        this.merkKendaraan = merkKendaraan;
    }

    public int getDurasiParkir() {
        return durasiParkir;
    }

    public void setDurasiParkir(int durasiParkir) {
        this.durasiParkir = durasiParkir;
    }

    public int getTotalBiaya() {
        return totalBiaya;
    }

    public void setTotalBiaya(int totalBiaya) {
        this.totalBiaya = totalBiaya;
    }
}
