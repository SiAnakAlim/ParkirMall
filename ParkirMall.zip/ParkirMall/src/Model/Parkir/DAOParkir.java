package Model.Parkir;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOParkir implements InterfaceDAOParkir {

    @Override
    public void insert(ModelParkir parkir) {
        try {
            String query = "INSERT INTO data_parkir (Nama, Plat, Merk, Durasi, Total) VALUES (?, ?, ?, ?, ?)";
            int totalBiaya = hitungTotalBiayaParkir(parkir.getDurasiParkir());
            PreparedStatement statement = Connector.connect().prepareStatement(query);
            statement.setString(1, parkir.getNamaPemilik());
            statement.setString(2, parkir.getPlatNomor());
            statement.setString(3, parkir.getMerkKendaraan());
            statement.setInt(4, parkir.getDurasiParkir());
            statement.setInt(5, totalBiaya);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Input Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public void update(ModelParkir parkir) {
        try {
            String query = "UPDATE data_parkir SET Nama=?, Merk=?, Durasi=?, Total=? WHERE Id=?";
            int totalBiaya = hitungTotalBiayaParkir(parkir.getDurasiParkir());
            PreparedStatement statement = Connector.connect().prepareStatement(query);
            statement.setString(1, parkir.getNamaPemilik());
            statement.setString(2, parkir.getMerkKendaraan());
            statement.setInt(3, parkir.getDurasiParkir());
            statement.setInt(4, totalBiaya);
            statement.setString(5, parkir.getPlatNomor());
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Update Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public void delete(int id) {
        try {
            String query = "DELETE FROM data_parkir WHERE Id=?";
            PreparedStatement statement = Connector.connect().prepareStatement(query);
            statement.setInt(1, id);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public List<ModelParkir> getAll() {
        List<ModelParkir> listParkir = new ArrayList<>();
        try {
            Statement statement = Connector.connect().createStatement();
            String query = "SELECT * FROM data_parkir";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                ModelParkir parkir = new ModelParkir();
                parkir.setId(resultSet.getInt("Id"));
                parkir.setNamaPemilik(resultSet.getString("Nama"));
                parkir.setPlatNomor(resultSet.getString("Plat"));
                parkir.setMerkKendaraan(resultSet.getString("Merk"));
                parkir.setDurasiParkir(resultSet.getInt("Durasi"));
                parkir.setTotalBiaya(resultSet.getInt("Total")); // Mengambil total biaya dari database
                listParkir.add(parkir);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
        return listParkir;
    }

    private int hitungTotalBiayaParkir(int durasi) {
        int totalBiaya = 0;
        if (durasi <= 3) {
            totalBiaya = durasi * 5000;
        } else {
            totalBiaya = (3 * 5000) + ((durasi - 3) * 1000);
        }
        return totalBiaya;
    }
}
