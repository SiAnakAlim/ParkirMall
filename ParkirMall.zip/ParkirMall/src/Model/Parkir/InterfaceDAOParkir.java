package Model.Parkir;

import java.util.List;

public interface InterfaceDAOParkir {
    // Method untuk memasukkan suatu data parkir
    public void insert(ModelParkir parkir);
    
    // Method untuk mengupdate (mengedit) suatu data parkir
    public void update(ModelParkir parkir);
    
    // Method untuk menghapus suatu data parkir berdasarkan ID
    public void delete(int id);
    
    // Method untuk mengambil semua data parkir
    public List<ModelParkir> getAll();
}
