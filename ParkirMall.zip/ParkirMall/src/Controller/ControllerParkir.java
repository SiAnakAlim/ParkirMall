package Controller;

import Model.Parkir.*;
import View.Parkir.*;
import java.util.List;
import javax.swing.JOptionPane;

public class ControllerParkir {

    ViewData halamanTable;
    InputData halamanInput;
    EditData halamanEdit;

    InterfaceDAOParkir daoParkir;

    // Variabel untuk menyimpan data parkir dari database
    List<ModelParkir> daftarParkir;

    // Constructor untuk halaman Table Parkir
    public ControllerParkir(ViewData halamanTable) {
        this.halamanTable = halamanTable;
        this.daoParkir = new DAOParkir();
    }

    // Constructor untuk halaman Input Parkir
    public ControllerParkir(InputData halamanInput) {
        this.halamanInput = halamanInput;
        this.daoParkir = new DAOParkir();
    }

    // Constructor untuk halaman Edit Parkir
    public ControllerParkir(EditData halamanEdit) {
        this.halamanEdit = halamanEdit;
        this.daoParkir = new DAOParkir();
    }

public void showAllParkir() {
    daftarParkir = daoParkir.getAll();
    ModelTable table = new ModelTable(daftarParkir);
    halamanTable.getTableParkir().setModel(table); // Menggunakan getTableParkir() untuk mendapatkan tabel
}

    // Method untuk menambahkan data parkir baru
    public void insertParkir() {
        try {
            ModelParkir parkirBaru = new ModelParkir();
            String nama = halamanInput.getInputNama();
            String plat = halamanInput.getInputPlat();
            String merk = halamanInput.getInputMerk();
            int durasi = halamanInput.getInputDurasi();

            if (nama.isEmpty() || plat.isEmpty() || merk.isEmpty() || durasi <= 0) {
                throw new Exception("Harap lengkapi semua field dengan benar.");
            }

            parkirBaru.setNamaPemilik(nama);
            parkirBaru.setPlatNomor(plat);
            parkirBaru.setMerkKendaraan(merk);
            parkirBaru.setDurasiParkir(durasi);

            daoParkir.insert(parkirBaru);
            JOptionPane.showMessageDialog(null, "Data parkir berhasil ditambahkan.");
            halamanInput.dispose();
            showAllParkir(); // Refresh tabel setelah penambahan
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    // Method untuk mengedit data parkir
    public void editParkir(int id) {
        try {
            ModelParkir parkirYangMauDiedit = new ModelParkir();
            String nama = halamanEdit.getInputNama();
            String plat = halamanEdit.getInputPlat();
            String merk = halamanEdit.getInputMerk();
            int durasi = halamanEdit.getInputDurasi();

            if (nama.isEmpty() || plat.isEmpty() || merk.isEmpty() || durasi <= 0) {
                throw new Exception("Harap lengkapi semua field dengan benar.");
            }

            parkirYangMauDiedit.setId(id);
            parkirYangMauDiedit.setNamaPemilik(nama);
            parkirYangMauDiedit.setPlatNomor(plat);
            parkirYangMauDiedit.setMerkKendaraan(merk);
            parkirYangMauDiedit.setDurasiParkir(durasi);

            daoParkir.update(parkirYangMauDiedit);
            JOptionPane.showMessageDialog(null, "Data parkir berhasil diubah.");
            halamanEdit.dispose();
            showAllParkir(); // Refresh tabel setelah pengeditan
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    // Method untuk menghapus data parkir
    public void deleteParkir(int id) {
        try {
            daoParkir.delete(id);
            JOptionPane.showMessageDialog(null, "Data parkir berhasil dihapus.");
            showAllParkir(); // Refresh tabel setelah penghapusan
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    public List<ModelParkir> getAll() {
    return daoParkir.getAll();
}

}
