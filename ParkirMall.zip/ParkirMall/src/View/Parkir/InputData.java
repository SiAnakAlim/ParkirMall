package View.Parkir;

import Controller.ControllerParkir;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InputData extends JFrame {
    // Membuat sebuah instance bernama controller dari class "ControllerParkir".
    ControllerParkir controller;
    
    JLabel header = new JLabel("Input Data Parkir");
    JLabel labelInputNama = new JLabel("Nama Pemilik");
    JLabel labelInputPlat = new JLabel("Plat Nomor");
    JLabel labelInputMerk = new JLabel("Merk Kendaraan");
    JLabel labelInputDurasi = new JLabel("Durasi Parkir (jam)");
    
    JTextField inputNama = new JTextField();
    JTextField inputPlat = new JTextField();
    JTextField inputMerk = new JTextField();
    JTextField inputDurasi = new JTextField();
    
    JButton tombolTambah = new JButton("Tambah Data Parkir");
    JButton tombolKembali = new JButton("Kembali");

    public InputData() {
        setTitle("Input Data Parkir");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setSize(480, 400); // Menyesuaikan lebar frame
        
        // Mengatur font dan warna untuk tampilan yang lebih menarik
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.BLUE);
        
        labelInputNama.setFont(new Font("Arial", Font.PLAIN, 16));
        labelInputPlat.setFont(new Font("Arial", Font.PLAIN, 16));
        labelInputMerk.setFont(new Font("Arial", Font.PLAIN, 16));
        labelInputDurasi.setFont(new Font("Arial", Font.PLAIN, 16));
        
        inputNama.setFont(new Font("Arial", Font.PLAIN, 16));
        inputPlat.setFont(new Font("Arial", Font.PLAIN, 16));
        inputMerk.setFont(new Font("Arial", Font.PLAIN, 16));
        inputDurasi.setFont(new Font("Arial", Font.PLAIN, 16));
        
        tombolTambah.setFont(new Font("Arial", Font.BOLD, 16));
        tombolTambah.setBackground(Color.GREEN);
        tombolTambah.setForeground(Color.WHITE);
        
        tombolKembali.setFont(new Font("Arial", Font.BOLD, 16));
        tombolKembali.setBackground(Color.RED);
        tombolKembali.setForeground(Color.WHITE);

        add(header);
        add(labelInputNama);
        add(labelInputPlat);
        add(labelInputMerk);
        add(labelInputDurasi);
        add(inputNama);
        add(inputPlat);
        add(inputMerk);
        add(inputDurasi);
        add(tombolTambah);
        add(tombolKembali);

        header.setBounds(120, 8, 240, 30);
        labelInputNama.setBounds(20, 50, 200, 24);
        inputNama.setBounds(20, 75, 440, 36);
        labelInputPlat.setBounds(20, 115, 200, 24);
        inputPlat.setBounds(20, 140, 440, 36);
        labelInputMerk.setBounds(20, 180, 200, 24);
        inputMerk.setBounds(20, 205, 440, 36);
        labelInputDurasi.setBounds(20, 245, 200, 24);
        inputDurasi.setBounds(20, 270, 440, 36);
        tombolKembali.setBounds(20, 315, 215, 40);
        tombolTambah.setBounds(240, 315, 215, 40);

        controller = new ControllerParkir(this); // Kita panggil konstruktor ControllerParkir dengan parameter InputData

        tombolKembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ViewData();
            }
        });

        tombolTambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.insertParkir();
            }
        });
    }
    
    public String getInputNama() {
        return inputNama.getText();
    }
    
    public String getInputPlat() {
        return inputPlat.getText();
    }
    
    public String getInputMerk() {
        return inputMerk.getText();
    }
    
    public int getInputDurasi() {
        try {
            return Integer.parseInt(inputDurasi.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Durasi harus berupa angka.");
            return 0;
        }
    }
}
