package View.Parkir;

import Controller.ControllerParkir;
import Model.Parkir.ModelTable;
import Model.Parkir.ModelParkir;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewData extends JFrame {
     private JTable tableParkir;

    public JTable getTableParkir() {
        return tableParkir;
    }
    ControllerParkir controller;
    JTable table;
    JScrollPane scrollPane;
    JButton tombolTambah, tombolEdit, tombolDelete, tombolKembali;

    public ViewData() {
        setTitle("Data Parkir");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        controller = new ControllerParkir(this);
        JLabel header = new JLabel("Data Parkir Kendaraan");
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.BLUE);
        header.setBounds(20, 20, 300, 30);
        add(header);

        tombolTambah = new JButton("Tambah Data");
        tombolTambah.setFont(new Font("Arial", Font.BOLD, 14));
        tombolTambah.setBackground(Color.GREEN);
        tombolTambah.setForeground(Color.WHITE);
        tombolTambah.setBounds(20, 60, 150, 30);
        add(tombolTambah);

        tombolEdit = new JButton("Edit Data");
        tombolEdit.setFont(new Font("Arial", Font.BOLD, 14));
        tombolEdit.setBackground(Color.ORANGE);
        tombolEdit.setForeground(Color.WHITE);
        tombolEdit.setBounds(180, 60, 150, 30);
        add(tombolEdit);

        tombolDelete = new JButton("Hapus Data");
        tombolDelete.setFont(new Font("Arial", Font.BOLD, 14));
        tombolDelete.setBackground(Color.RED);
        tombolDelete.setForeground(Color.WHITE);
        tombolDelete.setBounds(340, 60, 150, 30);
        add(tombolDelete);

        tombolKembali = new JButton("Kembali");
        tombolKembali.setFont(new Font("Arial", Font.BOLD, 14));
        tombolKembali.setBackground(Color.GRAY);
        tombolKembali.setForeground(Color.WHITE);
        tombolKembali.setBounds(500, 60, 150, 30);
        add(tombolKembali);

        tombolTambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new InputData();
            }
        });

        tombolEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    int id = (int) table.getValueAt(row, 0);
                    controller.editParkir(id);
                } else {
                    JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit");
                }
            }
        });

        tombolDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    int id = (int) table.getValueAt(row, 0);
                    controller.deleteParkir(id);
                } else {
                    JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus");
                }
            }
        });

        tombolKembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new InputData();
            }
        });

        // Membuat tabel untuk menampilkan data parkir
        List<ModelParkir> listParkir = controller.getAll();
        ModelTable modelTable = new ModelTable(listParkir);
        table = new JTable(modelTable);
        scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 100, 740, 240);
        add(scrollPane);

        setVisible(true);
    }

    public void refreshTable() {
        List<ModelParkir> listParkir = controller.getAll();
        ModelTable modelTable = new ModelTable(listParkir);
        table.setModel(modelTable);
    }
}
